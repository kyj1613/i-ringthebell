package ctu.kcn.i_ringthebell;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class AppInfoActivity extends AppCompatActivity {

    TextView tvInfo;
    TextView tvVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_info);

        tvInfo = (TextView)findViewById(R.id.textView7);

        String rslt = " Developer" + "\n";
        rslt += "  - Hai Ba Yo!" + "\n";
        rslt += "       Kim Yejin" + "\n";
        rslt += "       Min Chehwa" + "\n";
        rslt += "       Kim Seyoung" + "\n";
        rslt += "       Jeong Subeen" + "\n";
        rslt += "  - Luong Vinh Quoc Danh" + "\n\n";
        rslt += " Release Date: 2019.08.15" + "\n";
        rslt += " This app was developed by Android Studio" + "\n";

        tvInfo.setText(rslt);

        tvVersion = (TextView)findViewById(R.id.textView8);
        String rslt2 = "ver.1.0  ";

        tvVersion.setText(rslt2);
    }

}
