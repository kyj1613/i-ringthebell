package ctu.kcn.i_ringthebell;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.AudioManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    final static String TAG = "MainActivity";
    final int ADD_CODE = 100;
    final int UPDATE_CODE = 200;

    private ArrayList<Time> timeList;
    private MyAdapter myAdapter;
    private ListView listView;

    TimeDBHelper dbHelper;

    AlarmManager mAlarmManager;
    HashMap<Integer, Integer> storedAlarm = new HashMap<Integer, Integer>();
    int lastReqCode = 0;
    int prevTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "보임?onCreate");
        Log.d(TAG, "lastReqCode = " + lastReqCode);
        Intent intent = new Intent(this, AlarmReceiver.class);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new TimeDBHelper(this);

        timeList = new ArrayList<Time>();
        myAdapter = new MyAdapter(this, R.layout.custom_adapter_view, timeList);

        listView = (ListView) findViewById(R.id.my_listView);

        listView.setAdapter(myAdapter);

        readAllTimes();
        registExistingTime(timeList);

        //delete setting alarm time
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int pos, long id){
                final int position = pos;

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Xác nhận xóa");
                builder.setMessage("Bạn muốn xóa báo thức " + timeList.get(position).getHour() + ":" + timeList.get(position).getMinute() + " không?");
                builder.setPositiveButton("xóa", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SQLiteDatabase db = dbHelper.getWritableDatabase();
                        String whereClause = TimeDBHelper.COL_ID + "=?";
                        String[] whereArgs = new String[] { String.valueOf(timeList.get(position).get_id()) };
                        db.delete(TimeDBHelper.TABLE_NAME, whereClause, whereArgs);
                        dbHelper.close();

                        String key = timeList.get(position).getHour() + timeList.get(position).getMinute();  Log.i(TAG, "cancel할 때 key 값 -- " + key);
                        cancelAlarm(storedAlarm.get(Integer.parseInt(key)));
                        storedAlarm.remove(Integer.parseInt(key));
                        Log.i(TAG, "cancel 완료");

                        readAllTimes();
                        myAdapter.notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("Hủy", null);
                builder.show();
                return true;
            }
        });

        //edit chosen setting alarm time
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id) {
                Intent intent = new Intent(MainActivity.this, UpdateActivity.class);
                intent.putExtra("timeDto", timeList.get(pos));

                prevTime = Integer.parseInt(timeList.get(pos).getHour()) * 100 + Integer.parseInt(timeList.get(pos).getMinute());

                startActivityForResult(intent, UPDATE_CODE);
            }
        });
    }

    @Override
    protected void onResume(){
        super.onResume();
        setVolumeControlStream ( AudioManager.STREAM_MUSIC );
        readAllTimes();  Log.d(TAG, "onResume() 안이야 222 registExisingTime 전이다잉");
        myAdapter.notifyDataSetChanged(); Log.d(TAG, "storedAlarm 크기 = " + storedAlarm.size());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.option_add:
                Intent intent = new Intent(this, AddActivity.class);
                intent.putExtra("reqCode", lastReqCode);
                startActivityForResult(intent, ADD_CODE);   Log.d(TAG, "보임?add");
                break;
            case R.id.option_copyright:
                Intent intent2 = new Intent(this, AppInfoActivity.class);
                startActivity(intent2);
                break;
            case R.id.option_immediate:
                Intent intent3 = new Intent(this, RingActivity.class);
                startActivity(intent3);
                break;
            case R.id.option_close:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void readAllTimes(){
        timeList.clear();

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TimeDBHelper.TABLE_NAME, null);

        while(cursor.moveToNext()){
            long id = cursor.getInt(cursor.getColumnIndex(TimeDBHelper.COL_ID));
            String hour = cursor.getString(cursor.getColumnIndex(TimeDBHelper.COL_HOUR));
            String minute = cursor.getString(cursor.getColumnIndex(TimeDBHelper.COL_MINUTE));

            timeList.add( new Time(id, hour, minute) );
        }
        cursor.close();

        Collections.sort(timeList);
        dbHelper.close();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == ADD_CODE){
            switch(resultCode){
                case RESULT_OK:          Log.d(TAG, "RESULT_OK받았어");
                    Toast.makeText(this, "Đặt báo thức được hoàn thành", Toast.LENGTH_SHORT).show();
                    Time time = (Time)data.getSerializableExtra("result");
                    registAlarm(time);//registAlarm(timeList);
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "Đặt báo thức bị hủy", Toast.LENGTH_SHORT).show();
                    break;
            }
        } else if (requestCode == UPDATE_CODE) {
            switch(resultCode){
                case RESULT_OK:
                    Toast.makeText(this, " Thay đổi báo thức được hoàn thành", Toast.LENGTH_SHORT).show();
                    Time time = (Time)data.getSerializableExtra("result");
                    editAlarm(prevTime, time);//editAlarm(timeList, prevTime, newTime);
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "Thay đổi báo thức bị hủy", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }

    private void registExistingTime(ArrayList<Time> timeList) {
        Log.i(TAG, "registExistingAlarm 안");

        int[] settingTime = new int[timeList.size()];    Log.i(TAG, "timeList의 size -- " + timeList.size());
        for(int i = 0; i < settingTime.length; i++) {
            settingTime[i] = Integer.parseInt(timeList.get(i).getHour()) * 100 + Integer.parseInt(timeList.get(i).getMinute());
        }
        int index = 0;

        mAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);  Log.i(TAG, "Alarm Manager");
        // 알람 등록
        Intent intent = new Intent(this, AlarmReceiver.class);  Log.i(TAG, "알람 등록");

        long triggerTime = 0;
        long intervalTime = 24 * 60 * 60 * 1000;// 24시간
        Log.i(TAG, "interval 설정");

        while(index < settingTime.length) {
            PendingIntent pending = getPendingIntent(intent, lastReqCode);  //0809 수정, reqCode는 db의 id 값으로 하는게 좋을듯, 삭제기능할 때 확인 후 수정 필요
            Log.i(TAG, "pendingIntent get 끝");

            triggerTime = setTriggerTime(settingTime[index]);
            Log.i(TAG, "triggerTime set 끝");

            mAlarmManager.setRepeating(AlarmManager.RTC_WAKEUP, triggerTime, intervalTime, pending);
            Log.i(TAG, "alarmManager setRepeating");

            storedAlarm.put(settingTime[index], lastReqCode);
            lastReqCode++;  Log.i(TAG, "HashMap에 저장된 value 값" + settingTime[index] + " = " + storedAlarm.get(settingTime[index]));
            index++;
        }
    }

    //add alarm
    private void registAlarm(Time time) {
        Log.i(TAG, "registAlarm 안");

        int newTime = Integer.parseInt(time.getHour()) * 100 + Integer.parseInt(time.getMinute());

        mAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);  Log.i(TAG, "Alarm Manager");
        // 알람 등록
        Intent intent = new Intent(this, AlarmReceiver.class);  Log.i(TAG, "알람 등록");

        long triggerTime = 0;
        long intervalTime = 24 * 60 * 60 * 1000;// 24시간
        Log.i(TAG, "interval 설정");

        PendingIntent pending = getPendingIntent(intent, lastReqCode);  //0809 수정, reqCode는 db의 id 값으로 하는게 좋을듯, 삭제기능할 때 확인 후 수정 필요
        Log.i(TAG, "add -- pendingIntent get 끝");

        triggerTime = setTriggerTime(newTime);
        Log.i(TAG, "add -- triggerTime set 끝");

        mAlarmManager.setRepeating(AlarmManager.RTC_WAKEUP, triggerTime, intervalTime, pending);
        Log.i(TAG, "add -- alarmManager setRepeating");

        storedAlarm.put(newTime, lastReqCode);
        lastReqCode++;  Log.i(TAG, "add -- HashMap에 저장된 value 값" + newTime + " = " + storedAlarm.get(newTime));
        Log.d(TAG, "storedAlarm 크기 = " + storedAlarm.size());
    }

    //edit alarm
    private void editAlarm(int prevTime, Time time) {
        Log.i(TAG, "editAlarm 안");

        int value = storedAlarm.get(prevTime);   Log.d(TAG, "edit -- prevTime이 key 값인 value --  " + value);
        cancelAlarm(value);

        int newTime = Integer.parseInt(time.getHour()) * 100 + Integer.parseInt(time.getMinute());

        mAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);  Log.i(TAG, "edit -- Alarm Manager");
        // 알람 등록
        Intent intent = new Intent(this, AlarmReceiver.class);  Log.i(TAG, "edit -- 알람 등록");

        long triggerTime = 0;
        long intervalTime = 24 * 60 * 60 * 1000;// 24시간
        Log.i(TAG, "interval 설정");

        int reqCode = storedAlarm.get(prevTime);
        PendingIntent pending = getPendingIntent(intent, reqCode);  //0809 수정, reqCode는 db의 id 값으로 하는게 좋을듯, 삭제기능할 때 확인 후 수정 필요
        Log.i(TAG, "edit -- pendingIntent get 끝");

        triggerTime = setTriggerTime(newTime);
        Log.i(TAG, "edit -- triggerTime set 끝");

        mAlarmManager.setRepeating(AlarmManager.RTC_WAKEUP, triggerTime, intervalTime, pending);
        Log.i(TAG, "edit -- alarmManager setRepeating");

        storedAlarm.remove(prevTime);
        storedAlarm.put(newTime, reqCode);
        lastReqCode++;  Log.i(TAG, "edit -- HashMap에 저장된 value 값" + newTime + " = " + storedAlarm.get(newTime));
    }

    private PendingIntent getPendingIntent(Intent intent, int reqCode) {             Log.i(TAG, "pendingIntent get함");
        PendingIntent pIntent = PendingIntent.getBroadcast(this, reqCode, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        return pIntent;
    }

    private long setTriggerTime(int time) {             Log.i(TAG, "triggerTime(parameter) set함");
        // current Time
        long atime = System.currentTimeMillis();
        // alarm time
        Calendar curTime = Calendar.getInstance();
        curTime.set(Calendar.HOUR_OF_DAY, (time / 100));  Log.i(TAG, "세팅 시간" + (time/100));//this.mAlarmData.getHour(this));
        curTime.set(Calendar.MINUTE, (time % 100));  Log.i(TAG, "세팅 분" + (time % 100));//this.mAlarmData.getMinute(this));
        curTime.set(Calendar.SECOND, 0);
        curTime.set(Calendar.MILLISECOND, 0);

        long btime = curTime.getTimeInMillis();
        long triggerTime = btime;
        if (atime > btime)
            triggerTime += 1000 * 60 * 60 * 24;

        return triggerTime;
    }

    //0809 수정, 삭제기능 만들때 reqCode 등 생각해보아야 함, 일단 생략
    private void cancelAlarm(int reqCode) {             Log.i(TAG, "cancelAlarm() 안입니다.");
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pending = getPendingIntent(intent, reqCode);
        this.mAlarmManager.cancel(pending);
    }

}
