package ctu.kcn.i_ringthebell;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class AddActivity extends AppCompatActivity {
    private static final String TAG = "AddActivity";
    TimeDBHelper dbHelper;
    TimePicker mTimePicker;
    Time timeDto;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        dbHelper = new TimeDBHelper(this);
        mTimePicker = (TimePicker)findViewById(R.id.timePicker);

    }

    public void onClick(View v){
        switch(v.getId()){
            case R.id.btn_add:
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues value = new ContentValues();

                int hour, min;

                if(Build.VERSION.SDK_INT >= 23) {
                    hour = mTimePicker.getHour();
                    min = mTimePicker.getMinute();
                } else {
                    hour = mTimePicker.getCurrentHour();
                    min = mTimePicker.getCurrentMinute();
                }  Log.d(TAG, "pick된 hour=" +hour + "pick된 min=" + min);
                value.put(TimeDBHelper.COL_HOUR, hour);  Log.d(TAG, "52line -- value.put hour");
                value.put(TimeDBHelper.COL_MINUTE, min);  Log.d(TAG, "53line -- value.put min");

                long count = db.insert(TimeDBHelper.TABLE_NAME, null, value);

                if(count > 0) {
                    Log.d(TAG, "들어는 가니?");
                    //0814에 64 - 68 추가
                    timeDto = new Time(String.valueOf(hour), String.valueOf(min));
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("result", timeDto);
                    setResult(RESULT_OK, resultIntent);

                    dbHelper.close();
                    finish();
                } else {  Log.d(TAG, "count <= 0 이다 임마");
                    Toast.makeText(this, "새로운 알람 추가 실패!", Toast.LENGTH_SHORT).show();
                    dbHelper.close();
                }
                break;
            case R.id.btn_cancel:
                setResult(RESULT_CANCELED);
                finish();
                break;
        }
    }
}
