package ctu.schoolbell.i_ringthebell;

import android.app.AlarmManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class RingActivity extends AppCompatActivity {

    Button btnRing;

    protected static final String TAG = "RingActivity";
    private AudioManager mAudioManager;
    private MediaPlayer mPlayer;

    //    private MusicIntentReceiver myReceiver;
    private final int duration = 20;
    private final int sampleRate = 44100;
    private final int numSamples = duration * sampleRate;
    private final double sample[] = new double[numSamples];
    private final double freqOfTone = 1000;
    private final byte generatedSnd[] = new byte[2 * numSamples];
    double amplitude = 1.0;
    double twoPi = 2. * Math.PI;
    int f1 = 20;
    int f2 = 20000;
    private AudioTrack mAudioTrack;  //?

    AlarmManager mAlarmManager = null;
    boolean isPlaying = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ring);

    }

    @Override
    protected void onResume() {
        super.onResume();
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.button :
                genTone();
                byteConversion();

                long currTime = 0;
                long onTime = 4000;
                long startTime = System.currentTimeMillis();
                playSound();
                while (currTime - startTime < onTime) {
                    currTime = System.currentTimeMillis();
                }
                stopSound();

                mAudioManager = (AudioManager)getSystemService(AUDIO_SERVICE);
                mAudioManager.requestAudioFocus(afChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);

                break;
            /*case R.id.button2 :
                stopSound();
                break;*/
        }

    }

    AudioManager.OnAudioFocusChangeListener afChangeListener = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                mAudioManager.abandonAudioFocus(afChangeListener);
                if (null != mPlayer && mPlayer.isPlaying())
                    Log.i(TAG, "OnAudioFocusChangeListener 안 입니다");
                stopSound();
            }
        }
    };


    private void playSound() {
        mAudioTrack = new AudioTrack(mAudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, generatedSnd.length, AudioTrack.MODE_STATIC); Log.i(TAG, "playSound()   1");
        mAudioTrack.write(generatedSnd, 0, generatedSnd.length); Log.i(TAG, "playSound()   2");
        mAudioTrack.play();    Log.i(TAG, "playSound()   3");
        //0807 추가
        isPlaying = true;

    }

    private void stopSound() {
        if (mAudioTrack != null) {
            if (isPlaying == true) {
                mAudioTrack.stop();
                isPlaying = false;
            }
            mAudioTrack.release();
            mAudioTrack = null;
        }
    }

    //사인파 발생
    void genTone() {
        Log.i(TAG, "genTone 실행");
        for (int i = 0; i < numSamples; ++i) {
            sample[i] = Math.sin(2 * Math.PI * i / (sampleRate / freqOfTone));
        }
    }

    void byteConversion() {
        int idx = 0;

        for (final double dVal : sample) {
            final short val = (short) ((dVal * 32767));
            generatedSnd[idx++] = (byte) (val & 0x00ff);
            generatedSnd[idx++] = (byte) ((val & 0xff00) >>> 8);
        }
    }

}
