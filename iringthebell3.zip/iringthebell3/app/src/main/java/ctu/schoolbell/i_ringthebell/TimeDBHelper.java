package ctu.schoolbell.i_ringthebell;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class TimeDBHelper extends SQLiteOpenHelper {

    final static String TAG = "TimeDBHelper";

    final static String DB_NAME = "times.db";
    public final static String TABLE_NAME = "time_table";
    public final static String COL_ID = "id";
    public final static String COL_HOUR = "hour";
    public final static String COL_MINUTE = "minute";

    public TimeDBHelper(Context context) { super(context, DB_NAME, null, 1); }

    @Override
    public void onCreate(SQLiteDatabase db){
        String sql = "CREATE TABLE " + TABLE_NAME + " (" + COL_ID + " integer primary key autoincrement, " + COL_HOUR + " TEXT, " + COL_MINUTE + " TEXT)";
        Log.d(TAG, sql);
        db.execSQL(sql);

        db.execSQL("insert into " + TABLE_NAME + " values (null, '7', '0');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '8', '40');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '8', '50');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '9', '40');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '9', '50');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '11', '30');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '13', '30');");
/*        db.execSQL("insert into " + TABLE_NAME + " values (null, '14', '10');");*/
        db.execSQL("insert into " + TABLE_NAME + " values (null, '15', '10');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '15', '20');");
/*        db.execSQL("insert into " + TABLE_NAME + " values (null, '18', '45');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '20', '35');");*/
//        db.execSQL("insert into " + TABLE_NAME + " values (null, '1', '35');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '17', '0');");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

}
