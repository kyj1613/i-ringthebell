package ctu.schoolbell.i_ringthebell;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.util.Calendar;

import static android.content.Context.AUDIO_SERVICE;

public class AlarmReceiver extends BroadcastReceiver {
    protected static final String TAG = "AlarmReceiver";
    private static final String AUDIO_RECORDER_FOLDER = "AudioRecorder";
    private static final int RECORDER_BPP = 16;

    private AudioManager mAudioManager;

    //    private MusicIntentReceiver myReceiver;
    private String mFileName;
    private MediaPlayer mPlayer;
    private final int duration = 20;
    private final int sampleRate = 44100;
    private final int numSamples = duration * sampleRate;
    private int recordTimeInMillis;
    private final double sample[] = new double[numSamples];
    private final double freqOfTone = 1000;
    private final byte generatedSnd[] = new byte[2 * numSamples];
    double amplitude = 1.0;
    double twoPi = 2. * Math.PI;
    int f1 = 20;
    int f2 = 20000;
    private AudioTrack mAudioTrack;  //?

    AlarmManager mAlarmManager = null;
    boolean isPlaying = false;
    Time timeDto;

    public void onReceive(Context context, Intent intent) {
        Log.i(TAG, "onReceiver 처음 들어왔다");

        //0823추가
        int reqCode = intent.getIntExtra("reqCode", -1);  Log.i(TAG, "설정됐던 시간의 reqCode = " + reqCode);
        long triggerTime = intent.getLongExtra("triggerTime", 0); Log.i(TAG, "설정됐던 시간은 = " + triggerTime);
        //여기까지

        if (isStoragePermissionGranted()) {

            genTone();
            byteConversion();

            Log.i(TAG, "playSound()");

            long currTime = 0;
            long onTime = 3000;
            long offTime = 2000;
            int i = 0;

            Calendar calendar = Calendar.getInstance();  Log.i(TAG, "연월일" + calendar.get(Calendar.YEAR) + (calendar.get(Calendar.MONTH)+1) + calendar.get(Calendar.DATE));
            int todayDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK); Log.i(TAG, "요일은=" + todayDayOfWeek);//Sunday = 1, Monday = 2... Saturday = 7;
            int thisTime = calendar.get(Calendar.HOUR) * 100 + calendar.get(Calendar.MINUTE); Log.i(TAG, "시간은 =" + thisTime);
            //94, 95, 98, 115 추가
            if(todayDayOfWeek > 1 && todayDayOfWeek < 8) {
                while (i < 2) {
                    Toast.makeText(context, "signal out", Toast.LENGTH_SHORT).show();

                    long startTime = System.currentTimeMillis();
                    playSound();
                    while (currTime - startTime < onTime) {
                        currTime = System.currentTimeMillis();
                    }

                    long middleTime = System.currentTimeMillis();
                    stopSound();
                    while (currTime - middleTime < offTime) {
                        currTime = System.currentTimeMillis();
                    }
                    i++;
                }
            }

            //MainActivity.registExistingTime();
            //반복을 위해 재등록, 0823 추가
            mAlarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);  Log.i(TAG, "Alarm Manager");
            // 알람 등록
            //Intent intent = new Intent(this, AlarmReceiver.class);  Log.i(TAG, "알람 등록");

            //0826추가
            triggerTime = setTriggerTime(triggerTime);
            intent.putExtra("reqCode", reqCode);
            intent.putExtra("triggerTime", triggerTime);

            PendingIntent pending = PendingIntent.getBroadcast(context, reqCode, intent, PendingIntent.FLAG_UPDATE_CURRENT); Log.i(TAG, "pendingIntent get 끝");

            /*intent.putExtra("triggerTime", triggerTime);*/

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mAlarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pending);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                mAlarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pending);
            } else {
                mAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pending);
            }

            Log.i(TAG, "alarmManager setRepeating -- triggerTime = " + triggerTime);


        }
        else {  Toast.makeText(context, "You need to get permission to make signal", Toast.LENGTH_SHORT).show(); }


        mAudioManager = (AudioManager)context.getSystemService(AUDIO_SERVICE);
        mAudioManager.requestAudioFocus(afChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);

    }

    private long setTriggerTime(long triggerTime) {             Log.i(TAG, "triggerTime(parameter) set함");
        // current Time
        long atime = System.currentTimeMillis();   Log.i(TAG, "atime" + atime);
        // alarm time
        /*Calendar curTime = Calendar.getInstance();
        curTime.set(Calendar.HOUR_OF_DAY, (time / 100));  Log.i(TAG, "세팅 시간" + (time/100));//this.mAlarmData.getHour(this));
        curTime.set(Calendar.MINUTE, (time % 100));  Log.i(TAG, "세팅 분" + (time % 100));//this.mAlarmData.getMinute(this));
        curTime.set(Calendar.SECOND, 0);
        curTime.set(Calendar.MILLISECOND, 0);

        long btime = curTime.getTimeInMillis();   Log.i(TAG, "btime" + btime);
        long triggerTime = btime;   Log.i(TAG, "triggerTime = btime" + triggerTime);*/ Log.i(TAG, "이전 triggerTime = " + triggerTime);
        if (atime > triggerTime)
            triggerTime += 1000 * 60 * 60 * 24;   Log.i(TAG, "이후 if문 안에 triggerTime" + triggerTime);

        return triggerTime;
    }

    //오디오가 이미 플레이 되고 있으면.... 이부분 수정해야함
    AudioManager.OnAudioFocusChangeListener afChangeListener = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                mAudioManager.abandonAudioFocus(afChangeListener);
                if (null != mPlayer && mPlayer.isPlaying())
                    Log.i(TAG, "OnAudioFocusChangeListener 안 입니다요");

                stopSound();
            }
        }
    };

/*    private void startPlaying() {
        if (mFileName != null) {
            mPlayer = new MediaPlayer();
            try {
                mPlayer.setDataSource(mFileName);
                mPlayer.prepare();
                mPlayer.start();
            } catch (IOException e) {
                Log.e(TAG, "Media Player를 실행할 수 없습니다.");
            }
        } else {
            Log.e(TAG, "첫번째 테스트 시그널 발생");
        }
    }*/


    /*private void stopPlaying() {
        if (null != mPlayer) {
            if (mPlayer.isPlaying())
                mPlayer.stop();
            mPlayer.reset();
            mPlayer.release();
            mPlayer = null;
        }
    }*/


    void playSound() {
        mAudioTrack = new AudioTrack(mAudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, generatedSnd.length, AudioTrack.MODE_STATIC); Log.i(TAG, "playSound()   1");
        mAudioTrack.write(generatedSnd, 0, generatedSnd.length); Log.i(TAG, "playSound()   2");
        mAudioTrack.play();    Log.i(TAG, "playSound()   3");
        //0807 추가
        isPlaying = true;

    }

    private void stopSound() {
        if (mAudioTrack != null) {
            if (isPlaying == true) {
                mAudioTrack.stop();
                isPlaying = false;
            }
            mAudioTrack.release();
            mAudioTrack = null;
        }
    }

    //사인파 발생
    void genTone() {
        Log.i(TAG, "genTone 실행");
        for (int i = 0; i < numSamples; ++i) {
            sample[i] = Math.sin(2 * Math.PI * i / (sampleRate / freqOfTone));
        }
    }

    void byteConversion() {
        int idx = 0;

        for (final double dVal : sample) {
            final short val = (short) ((dVal * 32767));
            generatedSnd[idx++] = (byte) (val & 0x00ff);
            generatedSnd[idx++] = (byte) ((val & 0xff00) >>> 8);
        }
    }


    public boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            return true;
        }
        else { //permission is automatically granted on sdk<23 upon installation
            Log.v(TAG,"Storage Permission is granted");
            return true;
        }
    }
}
