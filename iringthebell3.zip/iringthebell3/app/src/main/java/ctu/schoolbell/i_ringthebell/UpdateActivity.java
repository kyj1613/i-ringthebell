package ctu.schoolbell.i_ringthebell;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class UpdateActivity extends AppCompatActivity {
    TimeDBHelper dbHelper;
    Time timeDto;
    TimePicker mTimePicker;
    Calendar mCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        dbHelper = new TimeDBHelper(this);
        mTimePicker = (TimePicker)findViewById(R.id.timePicker);

        Intent intent = getIntent();
        timeDto = (Time) intent.getSerializableExtra("timeDto");

    }
    public void onClick(View v){
        switch (v.getId()){
            case R.id.btn_update:
                SQLiteDatabase db = dbHelper.getWritableDatabase();

                ContentValues row = new ContentValues();

                int hour, min;

                if(Build.VERSION.SDK_INT >= 23) {
                    hour = mTimePicker.getHour();
                    min = mTimePicker.getMinute();
                } else {
                    hour = mTimePicker.getCurrentHour();
                    min = mTimePicker.getCurrentMinute();
                }

                row.put(TimeDBHelper.COL_HOUR, hour);
                row.put(TimeDBHelper.COL_MINUTE, min);

                String whereClause = TimeDBHelper.COL_ID + "=?";
                String[] whereArgs = new String[] { String.valueOf(timeDto.get_id()) };

                long count = db.update(TimeDBHelper.TABLE_NAME, row, whereClause, whereArgs);

                if(count > 0){
                    timeDto.setHour(String.valueOf(hour));
                    timeDto.setMinute(String.valueOf(min));

                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("result", timeDto);
                    setResult(RESULT_OK, resultIntent);
                    dbHelper.close();
                    finish();
                } else {
                    Toast.makeText(this, "Thất bại thay đổi!", Toast.LENGTH_SHORT).show();
                    dbHelper.close();
                }
                break;
            case R.id.btn_cancel:
                setResult(RESULT_CANCELED);
                break;
        }
        finish();
    }

}
