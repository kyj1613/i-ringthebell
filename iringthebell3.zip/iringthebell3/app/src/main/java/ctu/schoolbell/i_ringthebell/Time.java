package ctu.schoolbell.i_ringthebell;

import java.io.Serializable;

public class Time implements Serializable, Comparable<Time> {

    long _id;
    String hour;
    String minute;

    public Time(String hour, String minute) {
        this.hour = hour;
        this.minute = minute;
    }
    public Time(long _id, String hour, String minute) {
        this._id = _id;
        this.hour = hour;
        this.minute = minute;
    }

    public long get_id() {
        return _id;
    }

    public void set_id(long _id) {
        this._id = _id;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getMinute() {
        return minute;
    }

    public void setMinute(String minute) {
        this.minute = minute;
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append(_id);
        sb.append(".\t\t");
        sb.append(hour);
        sb.append(minute);

        return sb.toString();
    }

    @Override
    public int compareTo(Time t) {
        int mTime = Integer.parseInt(this.hour) * 100 + Integer.parseInt(this.minute);
        int newTime = Integer.parseInt(t.hour) * 100 + Integer.parseInt(t.minute);

        if(mTime < newTime) {
            return -1;
        } else if(mTime > newTime) {
            return 1;
        }
        return 0;
    }

}
